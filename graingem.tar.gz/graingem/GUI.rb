# frozen_string_literal: true

# graingem - a tiny image dithering GUI
# Provides a simple desktop UI to load an image, tweak settings via sliders/menus,
# preview the dithered result, and save the output.
#
# Run: ruby GUI.rb

require_relative 'ui'

begin
  require 'tk'
rescue LoadError
  warn "This GUI requires Ruby/Tk. Please install tk for your Ruby distribution."
  exit 2
end

begin
  require 'chunky_png'
rescue LoadError
  Tk.messageBox(type: 'ok', icon: 'error', title: 'Missing dependency',
                message: "This app requires the 'chunky_png' gem.\nInstall with: gem install chunky_png")
  exit 2
end

require 'tempfile'

module GUI
  # Helper for converting images to Tk::PhotoImage via PPM data
  module PPM
    module_function

    def from_chunky(png)
      w = png.width
      h = png.height
      header = "P6\n#{w} #{h}\n255\n"
      data = String.new(encoding: Encoding::BINARY)
      data << header
      h.times do |y|
        w.times do |x|
          px = png[x, y]
          r = (px >> 24) & 0xFF
          g = (px >> 16) & 0xFF
          b = (px >> 8) & 0xFF
          data << r.chr << g.chr << b.chr
        end
      end
      data
    end

    def from_mapped(mapped)
      h = mapped.length
      return "" if h.zero?
      w = mapped[0].length
      header = "P6\n#{w} #{h}\n255\n"
      data = String.new(encoding: Encoding::BINARY)
      data << header
      h.times do |y|
        row = mapped[y]
        w.times do |x|
          r, g, b = row[x]
          data << r.chr << g.chr << b.chr
        end
      end
      data
    end
  end

  class App
    include UI

    def initialize
      @root = TkRoot.new { title 'graingem — Dithering GUI' }
      begin
        @root.configure(background: '#1e1e1e')
      rescue
        # ignore if theme doesn't support background
      end

      # State
      @input_png = nil
      @input_path = nil
      @mapped = nil
      @palette_choice = TkVariable.new(String.new('bilevel'))
      @method_choice = TkVariable.new(String.new('floyd'))
      @gamma_value = TkVariable.new(String.new('2.2'))
      @pixel_value = TkVariable.new(String.new('1'))
      @custom_palette = TkVariable.new(String.new)
      # Additional controls
      @scale_value = TkVariable.new(String.new('100'))        # percent
      @line_scale_value = TkVariable.new(String.new('100'))   # percent vertical
      @smooth_value = TkVariable.new(String.new('0'))         # median radius 0..3
      @bleed_value = TkVariable.new(String.new('0'))          # 0..5
      @blur_value = TkVariable.new(String.new('0'))           # box blur radius 0..5
      @depth_value = TkVariable.new(String.new('0'))          # 0=no change; else levels (2..32)

      # Persistent tempfile for preview image to avoid repeated file creation
      @out_tmp = Tempfile.new(['graingem_out', '.ppm'])
      @out_tmp.binmode

      build_ui
      set_initial_geometry
      update_controls_state
    end

    def make_option_menu(parent, variable, values, command)
      if defined?(TkOptionMenu)
        klass = TkOptionMenu
        type = :option_menu
      elsif defined?(TkOptionMenubutton)
        klass = TkOptionMenubutton
        type = :menubutton
      elsif defined?(TkOptionMenuButton)
        klass = TkOptionMenuButton
        type = :menubutton
      else
        klass = nil
        type = :fallback
      end

      if klass
        if type == :option_menu
          klass.new(parent, variable, *values, command: command)
        else
          # TkOptionMenubutton/TkOptionMenuButton don’t accept -command; attach a trace on the variable instead
          widget = klass.new(parent, variable, *values)
          variable.trace('w', proc { command.call }) if command
          widget
        end
      else
        # Fallback: build a Menubutton+Menu manually
        mb = TkMenubutton.new(parent, text: variable.value)
        m = TkMenu.new(mb)
        mb.menu(m)
        values.each do |val|
          m.add('command', label: val, command: proc {
            variable.value = val
            mb.text(val)
            command.call if command
          })
        end
        mb
      end
    end

    def build_ui
      # Top controls
      top = TkFrame.new(@root)
      begin
        top.configure(background: '#1e1e1e')
      rescue
      end
      top.pack(side: 'top', fill: 'x', padx: 6, pady: 6)

      TkButton.new(top, text: 'Open…', command: proc { on_open }, relief: 'flat', borderwidth: 0, highlightthickness: 0,
                    background: '#2b2b2b', activebackground: '#3a3a3a', foreground: '#e0e0e0').pack(side: 'left', padx: 8, pady: 6)

      TkLabel.new(top, text: 'Method:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left', padx: 8)
      method_menu = make_option_menu(top, @method_choice, ['floyd', 'atkinson', 'jjn', 'stucki', 'burkes', 'sierra', 'sierra2', 'sierra_lite', 'stevenson', 'bayer2', 'bayer4', 'bayer8', 'cluster4', 'random', 'threshold'], proc { schedule_redither })
      begin
        method_menu.configure(relief: 'flat', borderwidth: 0, highlightthickness: 0, background: '#2b2b2b', activebackground: '#3a3a3a', foreground: '#e0e0e0')
      rescue
      end
      method_menu.pack(side: 'left', padx: 6)

      TkLabel.new(top, text: 'Palette:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left', padx: 8)
      palette_names = ['bilevel','gray4','gray8','gray16','gameboy','pico8','solar8','rainbow','warm6','cool6','mono_red4','mono_green4','mono_blue4','vibrant8','pastel8','custom']
      palette_menu = make_option_menu(top, @palette_choice, palette_names, proc { on_palette_changed })
      begin
        palette_menu.configure(relief: 'flat', borderwidth: 0, highlightthickness: 0, background: '#2b2b2b', activebackground: '#3a3a3a', foreground: '#e0e0e0')
      rescue
      end
      palette_menu.pack(side: 'left', padx: 6)

      @custom_entry = TkEntry.new(top, textvariable: @custom_palette, width: 28, relief: 'flat', borderwidth: 0, highlightthickness: 0,
                                  background: '#2b2b2b', foreground: '#e0e0e0', insertbackground: '#e0e0e0')
      @custom_entry.pack(side: 'left', padx: 6)
      @custom_entry.bind('KeyRelease') { schedule_redither }
      TkLabel.new(top, text: '(comma-separated hex colors)', background: '#1e1e1e', foreground: '#a0a0a0').pack(side: 'left')

      gamma_frame = TkFrame.new(top)
      begin
        gamma_frame.configure(background: '#1e1e1e')
      rescue
      end
      gamma_frame.pack(side: 'right')
      TkLabel.new(gamma_frame, text: 'Gamma:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @gamma_scale = TkScale.new(gamma_frame,
                                 from: 1.4, to: 3.0,
                                 orient: 'horizontal', length: 200,
                                 resolution: 0.1, variable: @gamma_value,
                                 highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                 background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                 command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      pixel_frame = TkFrame.new(top)
      begin
        pixel_frame.configure(background: '#1e1e1e')
      rescue
      end
      pixel_frame.pack(side: 'right')
      TkLabel.new(pixel_frame, text: 'Pixel size:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @pixel_scale = TkScale.new(pixel_frame,
                                 from: 1, to: 32,
                                 orient: 'horizontal', length: 160,
                                 resolution: 1, variable: @pixel_value,
                                 highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                 background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                 command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Extra sliders row (scaling and filters)
      extra = TkFrame.new(@root)
      begin
        extra.configure(background: '#1e1e1e')
      rescue
      end
      extra.pack(side: 'top', fill: 'x', padx: 6, pady: 2)

      # Scale
      TkLabel.new(extra, text: 'Scale %:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @scale_scale = TkScale.new(extra,
                                 from: 10, to: 400,
                                 orient: 'horizontal', length: 140,
                                 resolution: 10, variable: @scale_value,
                                 highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                 background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                 command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Line scale (vertical)
      TkLabel.new(extra, text: 'Line scale %:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @line_scale = TkScale.new(extra,
                                from: 50, to: 200,
                                orient: 'horizontal', length: 140,
                                resolution: 5, variable: @line_scale_value,
                                highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Smoothing (median)
      TkLabel.new(extra, text: 'Smoothing:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @smooth_scale = TkScale.new(extra,
                                  from: 0, to: 3,
                                  orient: 'horizontal', length: 100,
                                  resolution: 1, variable: @smooth_value,
                                  highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                  background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                  command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Bleed
      TkLabel.new(extra, text: 'Bleed:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @bleed_scale = TkScale.new(extra,
                                 from: 0, to: 5,
                                 orient: 'horizontal', length: 100,
                                 resolution: 1, variable: @bleed_value,
                                 highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                 background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                 command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Blur
      TkLabel.new(extra, text: 'Blur:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @blur_scale = TkScale.new(extra,
                                from: 0, to: 5,
                                orient: 'horizontal', length: 100,
                                resolution: 1, variable: @blur_value,
                                highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Depth (quantization levels)
      TkLabel.new(extra, text: 'Depth:', background: '#1e1e1e', foreground: '#e0e0e0').pack(side: 'left')
      @depth_scale = TkScale.new(extra,
                                 from: 0, to: 32,
                                 orient: 'horizontal', length: 100,
                                 resolution: 1, variable: @depth_value,
                                 highlightthickness: 0, sliderrelief: 'flat', troughcolor: '#3a3a3a', borderwidth: 0,
                                 background: '#2b2b2b', activebackground: '#bbbbbb', sliderlength: 22,
                                 command: proc { |_v| schedule_redither }).pack(side: 'left', padx: 6)

      # Bottom controls
      bottom = TkFrame.new(@root)
      begin
        bottom.configure(background: '#1e1e1e')
      rescue
      end
      bottom.pack(side: 'bottom', fill: 'x', padx: 6, pady: 6)
      TkButton.new(bottom, text: 'Save…', command: proc { on_save }, relief: 'flat', borderwidth: 0, highlightthickness: 0,
                   background: '#2b2b2b', activebackground: '#3a3a3a', foreground: '#e0e0e0').pack(side: 'right', padx: 8, pady: 6)

      # Preview area (single pane)
      preview = TkFrame.new(@root)
      begin
        preview.configure(background: '#1e1e1e')
      rescue
      end
      preview.pack(fill: 'both', expand: true)
      TkLabel.new(preview, text: 'Preview', background: '#1e1e1e', foreground: '#e0e0e0').pack(anchor: 'w', padx: 8, pady: 2)
      @out_image = TkPhotoImage.new
      # Canvas-based preview with rounded background
      @preview_canvas = TkCanvas.new(preview, background: '#1e1e1e', highlightthickness: 0, borderwidth: 0)
      @preview_canvas.pack(fill: 'both', expand: true, padx: 8, pady: 8)
      @preview_bg_items = []
      @preview_img_item = TkcImage.new(@preview_canvas, 0, 0, image: @out_image, anchor: 'center')
      @preview_canvas.bind('Configure') { draw_preview_background_and_center }
    end

    def set_initial_geometry
      # Choose a square size that fits within the current screen, targeting ~85% of the short edge
      begin
        sw = TkWinfo.screenwidth(@root)
        sh = TkWinfo.screenheight(@root)
      rescue
        sw = 1280
        sh = 800
      end
      short_edge = [sw, sh].min
      size = (short_edge * 0.85).to_i
      # Keep a sensible minimum but never exceed screen bounds
      size = [[size, 520].max, short_edge].min
      x = ((sw - size) / 2.0).to_i
      y = ((sh - size) / 2.0).to_i
      begin
        @root.minsize(420, 420)
      rescue
      end
      @root.geometry("#{size}x#{size}+#{x}+#{y}")
    end

    def on_palette_changed
      update_controls_state
      schedule_redither
    end

    def update_controls_state
      if @palette_choice.value == 'custom'
        @custom_entry.state = 'normal'
      else
        @custom_entry.state = 'disabled'
      end
    end

    def on_open
      path = Tk.getOpenFile(title: 'Open image (PNG)', filetypes: [['PNG files', '.png'], ['All files', '.*']])
      return if path.nil? || path.empty?
      begin
        png = ChunkyPNG::Image.from_file(path)
      rescue => e
        Tk.messageBox(type: 'ok', icon: 'error', title: 'Open failed', message: e.message)
        return
      end
      @input_png = png
      @input_path = path
      schedule_redither
    end

    def on_save
      unless @input_png
        Tk.messageBox(type: 'ok', icon: 'info', title: 'Nothing to save', message: 'Load an image and generate output first.')
        return
      end
      save_path = Tk.getSaveFile(title: 'Save output PNG', defaultextension: '.png',
                                 filetypes: [['PNG files', '.png'], ['All files', '.*']])
      return if save_path.nil? || save_path.empty?

      # Recompute at full resolution for saving (no preview downscale)
      mapped_full = compute_mapped(preview: false)
      if mapped_full.nil? || mapped_full.empty?
        Tk.messageBox(type: 'ok', icon: 'error', title: 'Save failed', message: 'No output to save.')
        return
      end
      h = mapped_full.length
      w = h > 0 ? mapped_full[0].length : 0
      out = UI::OutputPNG.new(w, h)
      h.times do |y|
        w.times do |x|
          r, g, b = mapped_full[y][x]
          out.set_rgb(x, y, r, g, b)
        end
      end
      begin
        out.save(save_path)
      rescue => e
        Tk.messageBox(type: 'ok', icon: 'error', title: 'Save failed', message: e.message)
        return
      end
      Tk.messageBox(type: 'ok', icon: 'info', title: 'Saved', message: "Saved to #{save_path}")
    end

    def refresh_original
      return unless @input_png
      ppm = PPM.from_chunky(@input_png)
      # Use a Tempfile to avoid passing binary with NULs through Ruby/Tk -data
      begin
        @orig_tmp.close! if defined?(@orig_tmp) && @orig_tmp
      rescue
        # ignore
      end
      @orig_tmp = Tempfile.new(['graingem_orig', '.ppm'])
      @orig_tmp.binmode
      @orig_tmp.write(ppm)
      @orig_tmp.flush
      @orig_image.configure(file: @orig_tmp.path, format: 'PPM')
    end

    def effective_palette
      name = @palette_choice.value
      if name == 'custom'
        arg = @custom_palette.value.to_s.strip
        if arg.empty?
          UI::Util.palette_from_arg('bilevel')
        else
          begin
            UI::Util.palette_from_arg(arg)
          rescue => e
            Tk.messageBox(type: 'ok', icon: 'error', title: 'Palette error', message: e.message)
            UI::Util.palette_from_arg('bilevel')
          end
        end
      else
        # Delegate to Util to resolve any built-in palette name
        UI::Util.palette_from_arg(name)
      end
    end

    def pixelate_chunky(png, block)
      return png if block <= 1
      w = png.width
      h = png.height
      out = ChunkyPNG::Image.new(w, h, ChunkyPNG::Color::WHITE)
      y = 0
      while y < h
        x = 0
        y_end = [y + block, h].min
        while x < w
          x_end = [x + block, w].min
          r_sum = 0
          g_sum = 0
          b_sum = 0
          count = 0
          yy = y
          while yy < y_end
            xx = x
            while xx < x_end
              px = png[xx, yy]
              r = (px >> 24) & 0xFF
              g = (px >> 16) & 0xFF
              b = (px >> 8) & 0xFF
              r_sum += r
              g_sum += g
              b_sum += b
              count += 1
              xx += 1
            end
            yy += 1
          end
          ar = (r_sum / count).round
          ag = (g_sum / count).round
          ab = (b_sum / count).round
          color = ChunkyPNG::Color.rgba(ar, ag, ab, 255)
          yy = y
          while yy < y_end
            xx = x
            while xx < x_end
              out[xx, yy] = color
              xx += 1
            end
            yy += 1
          end
          x += block
        end
        y += block
      end
      out
    end

    def resize_nearest(png, sx, sy)
      return png if (sx - 1.0).abs < 1e-6 && (sy - 1.0).abs < 1e-6
      w = png.width
      h = png.height
      nw = [[(w * sx).round, 1].max, 10_000].min
      nh = [[(h * sy).round, 1].max, 10_000].min
      out = ChunkyPNG::Image.new(nw, nh, ChunkyPNG::Color::WHITE)
      nh.times do |y|
        syi = [[(y / sy).floor, h - 1].min, 0].max
        nw.times do |x|
          sxi = [[(x / sx).floor, w - 1].min, 0].max
          out[x, y] = png[sxi, syi]
        end
      end
      out
    end

    def median_filter(png, radius)
      return png if radius <= 0
      w = png.width
      h = png.height
      out = ChunkyPNG::Image.new(w, h, ChunkyPNG::Color::WHITE)
      window = []
      h.times do |y|
        w.times do |x|
          window.clear
          y0 = [y - radius, 0].min + 0 # will be fixed next line
          y0 = [y - radius, 0].max
          y1 = [y + radius, h - 1].min
          x0 = [x - radius, 0].max
          x1 = [x + radius, w - 1].min
          yy = y0
          while yy <= y1
            xx = x0
            while xx <= x1
              px = png[xx, yy]
              r = (px >> 24) & 0xFF
              g = (px >> 16) & 0xFF
              b = (px >> 8) & 0xFF
              window << [r, g, b]
              xx += 1
            end
            yy += 1
          end
          # median per channel
          rs = window.map { |c| c[0] }.sort
          gs = window.map { |c| c[1] }.sort
          bs = window.map { |c| c[2] }.sort
          mid = rs.length / 2
          ar = rs[mid]
          ag = gs[mid]
          ab = bs[mid]
          out[x, y] = ChunkyPNG::Color.rgba(ar, ag, ab, 255)
        end
      end
      out
    end

    def box_blur(png, radius)
      return png if radius <= 0
      w = png.width
      h = png.height
      # horizontal pass
      tmp = ChunkyPNG::Image.new(w, h, ChunkyPNG::Color::WHITE)
      h.times do |y|
        w.times do |x|
          x0 = [x - radius, 0].max
          x1 = [x + radius, w - 1].min
          count = (x1 - x0 + 1)
          r_sum = g_sum = b_sum = 0
          xx = x0
          while xx <= x1
            px = png[xx, y]
            r_sum += (px >> 24) & 0xFF
            g_sum += (px >> 16) & 0xFF
            b_sum += (px >> 8) & 0xFF
            xx += 1
          end
          tmp[x, y] = ChunkyPNG::Color.rgba((r_sum / count).round, (g_sum / count).round, (b_sum / count).round, 255)
        end
      end
      # vertical pass
      out = ChunkyPNG::Image.new(w, h, ChunkyPNG::Color::WHITE)
      h.times do |y|
        w.times do |x|
          y0 = [y - radius, 0].max
          y1 = [y + radius, h - 1].min
          count = (y1 - y0 + 1)
          r_sum = g_sum = b_sum = 0
          yy = y0
          while yy <= y1
            px = tmp[x, yy]
            r_sum += (px >> 24) & 0xFF
            g_sum += (px >> 16) & 0xFF
            b_sum += (px >> 8) & 0xFF
            yy += 1
          end
          out[x, y] = ChunkyPNG::Color.rgba((r_sum / count).round, (g_sum / count).round, (b_sum / count).round, 255)
        end
      end
      out
    end

    def bleed_filter(png, radius, strength)
      return png if radius <= 0 || strength <= 0
      w = png.width
      h = png.height
      out = ChunkyPNG::Image.new(w, h, ChunkyPNG::Color::WHITE)
      h.times do |y|
        w.times do |x|
          # current color
          pxc = png[x, y]
          cr = (pxc >> 24) & 0xFF
          cg = (pxc >> 16) & 0xFF
          cb = (pxc >> 8) & 0xFF
          # find darkest neighbor
          darkest_lum = 1_000_000
          dr = cr; dg = cg; db = cb
          y0 = [y - radius, 0].max
          y1 = [y + radius, h - 1].min
          x0 = [x - radius, 0].max
          x1 = [x + radius, w - 1].min
          yy = y0
          while yy <= y1
            xx = x0
            while xx <= x1
              px = png[xx, yy]
              r = (px >> 24) & 0xFF
              g = (px >> 16) & 0xFF
              b = (px >> 8) & 0xFF
              lum = (0.2126*r + 0.7152*g + 0.0722*b)
              if lum < darkest_lum
                darkest_lum = lum
                dr = r; dg = g; db = b
              end
              xx += 1
            end
            yy += 1
          end
          a = [[strength, 1.0].min, 0.0].max
          nr = (cr*(1-a) + dr*a).round
          ng = (cg*(1-a) + dg*a).round
          nb = (cb*(1-a) + db*a).round
          out[x, y] = ChunkyPNG::Color.rgba(nr, ng, nb, 255)
        end
      end
      out
    end

    def quantize_levels(png, levels)
      return png if levels.nil? || levels.to_i <= 0
      lv = [[levels.to_i, 2].max, 256].min
      w = png.width
      h = png.height
      out = ChunkyPNG::Image.new(w, h, ChunkyPNG::Color::WHITE)
      step = 255.0 / (lv - 1)
      h.times do |y|
        w.times do |x|
          px = png[x, y]
          r = (px >> 24) & 0xFF
          g = (px >> 16) & 0xFF
          b = (px >> 8) & 0xFF
          qr = ( (r / step).round * step ).round.clamp(0,255)
          qg = ( (g / step).round * step ).round.clamp(0,255)
          qb = ( (b / step).round * step ).round.clamp(0,255)
          out[x, y] = ChunkyPNG::Color.rgba(qr, qg, qb, 255)
        end
      end
      out
    end

    # Compute the preprocessed source image based on current controls.
    # If preview: additionally downscale to fit the preview canvas to speed up rendering.
    def build_src_png(preview: true)
      src_png = @input_png
      return nil unless src_png
      # scaling
      sx = (@scale_value.value.to_f / 100.0)
      sy = (@line_scale_value.value.to_f / 100.0)
      src_png = resize_nearest(src_png, sx, sy)
      # smoothing (median)
      smooth_r = @smooth_value.value.to_i
      src_png = median_filter(src_png, smooth_r) if smooth_r > 0
      # blur (box)
      blur_r = @blur_value.value.to_i
      src_png = box_blur(src_png, blur_r) if blur_r > 0
      # bleed (toward darkest neighbor)
      bleed_r = @bleed_value.value.to_i
      if bleed_r > 0
        strength = [bleed_r / 5.0, 1.0].min
        src_png = bleed_filter(src_png, bleed_r, strength)
      end
      # depth (quantize)
      depth_lv = @depth_value.value.to_i
      src_png = quantize_levels(src_png, depth_lv) if depth_lv > 0
      # pixelation
      pixel_size = @pixel_value.value.to_i
      pixel_size = 1 if pixel_size < 1
      src_png = pixelate_chunky(src_png, pixel_size)

      if preview
        # Downscale to fit preview canvas to accelerate live updates
        maxw = maxh = nil
        begin
          cw = TkWinfo.width(@preview_canvas)
          ch = TkWinfo.height(@preview_canvas)
          # account for padding and rounded box margins
          maxw = [cw - 16, 1].max
          maxh = [ch - 16, 1].max
        rescue
        end
        if maxw && maxh && maxw > 0 && maxh > 0
          sf = [maxw.to_f / src_png.width, maxh.to_f / src_png.height, 1.0].min
          if sf < 0.999
            src_png = resize_nearest(src_png, sf, sf)
          end
        end
      end
      src_png
    end

    # Run dithering with current settings and return the mapped RGB array.
    # If preview: uses build_src_png(preview: true); otherwise full-res.
    def compute_mapped(preview: true)
      src_png = build_src_png(preview: preview)
      return nil unless src_png
      palette = effective_palette
      gamma = @gamma_value.value.to_f
      canvas = UI::Canvas.new(src_png)
      case @method_choice.value
      when 'threshold'
        UI::Dither.threshold_map(canvas, palette, gamma: gamma)
      when 'floyd'
        UI::Dither.floyd_steinberg(canvas, palette, gamma: gamma)
      when 'atkinson'
        UI::Dither.atkinson(canvas, palette, gamma: gamma)
      when 'jjn'
        UI::Dither.jjn(canvas, palette, gamma: gamma)
      when 'stucki'
        UI::Dither.stucki(canvas, palette, gamma: gamma)
      when 'burkes'
        UI::Dither.burkes(canvas, palette, gamma: gamma)
      when 'sierra'
        UI::Dither.sierra(canvas, palette, gamma: gamma)
      when 'sierra2'
        UI::Dither.sierra2(canvas, palette, gamma: gamma)
      when 'sierra_lite'
        UI::Dither.sierra_lite(canvas, palette, gamma: gamma)
      when 'stevenson'
        UI::Dither.stevenson(canvas, palette, gamma: gamma)
      when 'bayer2'
        UI::Dither.ordered_bayer2(canvas, palette, gamma: gamma)
      when 'bayer4'
        UI::Dither.ordered_bayer4(canvas, palette, gamma: gamma)
      when 'bayer8'
        UI::Dither.ordered_bayer8(canvas, palette, gamma: gamma)
      when 'cluster4'
        UI::Dither.ordered_cluster4(canvas, palette, gamma: gamma)
      when 'random'
        UI::Dither.random(canvas, palette, gamma: gamma)
      else
        UI::Dither.floyd_steinberg(canvas, palette, gamma: gamma)
      end
    end

    def redither
      return unless @input_png
      @mapped = compute_mapped(preview: true)
      return unless @mapped
      ppm = PPM.from_mapped(@mapped)
      # Reuse persistent Tempfile to avoid repeated file creation overhead
      begin
        @out_tmp.rewind
        @out_tmp.truncate(0)
      rescue
      end
      @out_tmp.write(ppm)
      @out_tmp.flush
      @out_image.configure(file: @out_tmp.path, format: 'PPM')
      draw_preview_background_and_center
    end

    def draw_preview_background_and_center
      return unless defined?(@preview_canvas) && @preview_canvas
      # Clear previous background items
      if @preview_bg_items
        @preview_bg_items.each do |item|
          begin
            item.delete
          rescue
          end
        end
        @preview_bg_items.clear
      else
        @preview_bg_items = []
      end

      # Dimensions
      begin
        w = TkWinfo.width(@preview_canvas)
        h = TkWinfo.height(@preview_canvas)
      rescue
        w = 400
        h = 300
      end
      pad = 8
      r = 14
      x0 = pad
      y0 = pad
      x1 = [w - pad, x0 + 2].max
      y1 = [h - pad, y0 + 2].max
      fill = '#2b2b2b'
      outline = ''

      # Core rectangles
      @preview_bg_items << TkcRectangle.new(@preview_canvas, x0 + r, y0, x1 - r, y1, fill: fill, outline: outline)
      @preview_bg_items << TkcRectangle.new(@preview_canvas, x0, y0 + r, x1, y1 - r, fill: fill, outline: outline)
      # Corners (arcs)
      @preview_bg_items << TkcArc.new(@preview_canvas, x0, y0, x0 + 2 * r, y0 + 2 * r, start: 180, extent: 90, style: 'pieslice', fill: fill, outline: outline)
      @preview_bg_items << TkcArc.new(@preview_canvas, x1 - 2 * r, y0, x1, y0 + 2 * r, start: 270, extent: 90, style: 'pieslice', fill: fill, outline: outline)
      @preview_bg_items << TkcArc.new(@preview_canvas, x0, y1 - 2 * r, x0 + 2 * r, y1, start: 90, extent: 90, style: 'pieslice', fill: fill, outline: outline)
      @preview_bg_items << TkcArc.new(@preview_canvas, x1 - 2 * r, y1 - 2 * r, x1, y1, start: 0, extent: 90, style: 'pieslice', fill: fill, outline: outline)

      # Ensure background sits behind the image
      begin
        @preview_bg_items.each { |it| it.lower }
      rescue
      end

      # Center image
      cx = (w / 2).to_i
      cy = (h / 2).to_i
      begin
        @preview_img_item.coords(cx, cy)
        @preview_img_item.raise
      rescue
      end
    end

    def schedule_redither
      # Debounce rapid slider/menu changes
      if defined?(@after_id) && @after_id
        Tk.after_cancel(@after_id) rescue nil
      end
      @after_id = Tk.after(220, proc { redither })
    end

    def run
      Tk.mainloop
    end
  end

  def self.run
    App.new.run
  end
end

if __FILE__ == $PROGRAM_NAME
  GUI.run
end
