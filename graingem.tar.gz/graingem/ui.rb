# frozen_string_literal: true

# graingem - a tiny image dithering CLI
# Provides argument parsing, image IO, and dithering dispatcher.

module UI
  VERSION = '0.1.0'

  HELP = <<~TXT
    graingem v#{VERSION} — ditherize images (PNG in/out)

    Usage:
      ruby main.rb input.png output.png [options]

    Options:
      --palette NAME               Built-ins: bilevel (default), gray4, gray8, gray16,
                                   gameboy, pico8, solar8, rainbow, warm6, cool6,
                                   mono_red4, mono_green4, mono_blue4, vibrant8, pastel8
      --palette COLORS             Custom comma-separated hex colors (e.g. "#000,#777,#fff")
      --method floyd               Floyd–Steinberg error diffusion (default)
      --method threshold           No diffusion; simple nearest-color mapping
      --method atkinson            Atkinson error diffusion (lightweight, soft)
      --method jjn                 Jarvis–Judice–Ninke error diffusion
      --method stucki              Stucki error diffusion
      --method burkes              Burkes error diffusion
      --method sierra              Sierra (three-row) error diffusion
      --method sierra2             Sierra two-row error diffusion
      --method sierra_lite         Sierra Lite error diffusion
      --method stevenson           Stevenson–Arce error diffusion
      --method bayer2              Ordered dithering with 2×2 Bayer matrix
      --method bayer4              Ordered dithering with 4×4 Bayer matrix
      --method bayer8              Ordered dithering with 8×8 Bayer matrix
      --method cluster4            Ordered clustered-dot halftone (4×4)
      --method random              Stochastic noise dithering
      --gamma G                    Gamma (display) used for luminance calculations; default 2.2
      --help                       Show this help

    Notes:
      - This tool reads and writes PNG files. It requires the 'chunky_png' gem.
        Install it via:  gem install chunky_png
  TXT

  module Util
    module_function

    def parse_hex_color(hex)
      h = hex.strip
      h = "##{h}" unless h.start_with?('#')
      case h.length
      when 4 # #rgb
        r = (h[1] * 2).to_i(16)
        g = (h[2] * 2).to_i(16)
        b = (h[3] * 2).to_i(16)
      when 7 # #rrggbb
        r = h[1..2].to_i(16)
        g = h[3..4].to_i(16)
        b = h[5..6].to_i(16)
      else
        raise ArgumentError, "Invalid color: #{hex}"
      end
      [r, g, b]
    end

    # Built-in named palettes
    PALETTES = begin
      g = lambda { |n|
        # n-level grayscale including 0 and 255
        (0...n).map { |i|
          v = (i * 255.0 / (n - 1)).round
          [v, v, v]
        }
      }

      # PICO-8 16-color palette
      pico8_hex = %w[
        000000 1D2B53 7E2553 008751 AB5236 5F574F C2C3C7 FFF1E8
        FF004D FFA300 FFEC27 00E436 29ADFF 83769C FF77A8 FFCCAA
      ]

      # Solarized base + accents (8 key colors)
      solar8_hex = %w[002B36 586E75 839496 93A1A1 B58900 CB4B16 DC322F 268BD2]

      # Rainbow-ish 7 colors
      rainbow_hex = %w[FF0000 FF7F00 FFFF00 00FF00 0000FF 4B0082 9400D3]

      # Warm and Cool tones
      warm6_hex = %w[3B0A0A 7A1E1E B33A3A D96B27 F2A65A F8D7A0]
      cool6_hex = %w[0A2A43 144E73 1B6F98 2C9AB7 77C1D4 BFE6EF]

      # Game Boy DMG greens (dark to light)
      gameboy_hex = %w[0F380F 306230 8BAC0F 9BBC0F]

      # Vibrant and Pastel sets
      vibrant8_hex = %w[FF3B30 FF9500 FFCC00 4CD964 5AC8FA 007AFF 5856D6 FF2D55]
      pastel8_hex  = %w[FFB3BA FFDFBA FFE6BA CCF1BA BAE1FF BAE1FF D4BAFF FFC8E1]

      mono = lambda { |hexes| hexes.map { |h| h.scan(/../).map { |p| p.to_i(16) } } }
      hx = lambda { |arr| arr.map { |h| parse_hex_color(h) } }

      {
        'bilevel' => [[0, 0, 0], [255, 255, 255]],
        'gray4'   => g.call(4),
        'gray8'   => g.call(8),
        'gray16'  => g.call(16),
        'gameboy' => hx.call(gameboy_hex),
        'pico8'   => hx.call(pico8_hex),
        'solar8'  => hx.call(solar8_hex),
        'rainbow' => hx.call(rainbow_hex),
        'warm6'   => hx.call(warm6_hex),
        'cool6'   => hx.call(cool6_hex),
        'vibrant8'=> hx.call(vibrant8_hex),
        'pastel8' => hx.call(pastel8_hex),
        'mono_red4'   => [[0,0,0],[85,0,0],[170,0,0],[255,0,0]],
        'mono_green4' => [[0,0,0],[0,85,0],[0,170,0],[0,255,0]],
        'mono_blue4'  => [[0,0,0],[0,0,85],[0,0,170],[0,0,255]]
      }
    end

    def palette_from_arg(arg)
      case arg
      when nil, ''
        PALETTES['bilevel']
      else
        key = arg.downcase
        if PALETTES.key?(key)
          PALETTES[key]
        else
          arg.split(',').map { |c| parse_hex_color(c) }
        end
      end
    end

    def puts_err(msg)
      $stderr.puts msg
    end
  end

  module Dither
    module_function

    # Compute luminance in gamma-correct manner; returns linear light [0..1]
    def to_linear_channel(c, gamma)
      # c in 0..255, convert to 0..1
      v = c / 255.0
      # Approximate sRGB gamma with provided gamma parameter
      v**gamma
    end

    def from_linear_channel(v, gamma)
      # v in 0..1 linear
      out = v**(1.0 / gamma)
      (out * 255).round.clamp(0, 255)
    end

    def nearest_color(r, g, b, palette)
      best_i = 0
      best_d = Float::INFINITY
      palette.each_with_index do |(pr, pg, pb), i|
        dr = r - pr
        dg = g - pg
        db = b - pb
        d = dr * dr + dg * dg + db * db
        if d < best_d
          best_d = d
          best_i = i
        end
      end
      palette[best_i]
    end

    def threshold_map(img, palette, gamma: 2.2)
      w = img.width
      h = img.height
      out = Array.new(h) { Array.new(w) { [0, 0, 0] } }

      h.times do |y|
        w.times do |x|
          r, g, b = img.get_rgb(x, y)
          nr, ng, nb = nearest_color(r, g, b, palette)
          out[y][x] = [nr, ng, nb]
        end
      end
      out
    end

    # Generic error diffusion with arbitrary kernel weights relative to (x,y)
    # weights: array of [dx, dy, w] with sum of w = 1.0 (or any factor; it's used as ratios)
    def error_diffusion(img, palette, weights)
      w = img.width
      h = img.height
      rbuf = Array.new(h) { Array.new(w, 0.0) }
      gbuf = Array.new(h) { Array.new(w, 0.0) }
      bbuf = Array.new(h) { Array.new(w, 0.0) }

      h.times do |y|
        w.times do |x|
          r, g, b = img.get_rgb(x, y)
          rbuf[y][x] = r.to_f
          gbuf[y][x] = g.to_f
          bbuf[y][x] = b.to_f
        end
      end

      out = Array.new(h) { Array.new(w) { [0, 0, 0] } }

      h.times do |y|
        w.times do |x|
          cr = rbuf[y][x]
          cg = gbuf[y][x]
          cb = bbuf[y][x]
          nr, ng, nb = nearest_color(cr.round, cg.round, cb.round, palette)
          out[y][x] = [nr, ng, nb]

          err_r = cr - nr
          err_g = cg - ng
          err_b = cb - nb

          weights.each do |dx, dy, wt|
            ny = y + dy
            nx = x + dx
            next if nx < 0 || nx >= w || ny < 0 || ny >= h
            rbuf[ny][nx] += err_r * wt
            gbuf[ny][nx] += err_g * wt
            bbuf[ny][nx] += err_b * wt
          end
        end
      end
      out
    end

    # Floyd–Steinberg error diffusion
    def floyd_steinberg(img, palette, gamma: 2.2)
      weights = [
        [1, 0, 7.0 / 16],
        [-1, 1, 3.0 / 16],
        [0, 1, 5.0 / 16],
        [1, 1, 1.0 / 16]
      ]
      error_diffusion(img, palette, weights)
    end

    # Atkinson error diffusion (each neighbor gets 1/8 of the error)
    def atkinson(img, palette, gamma: 2.2)
      weights = [
        [1, 0, 1.0 / 8],
        [2, 0, 1.0 / 8],
        [-1, 1, 1.0 / 8],
        [0, 1, 1.0 / 8],
        [1, 1, 1.0 / 8],
        [0, 2, 1.0 / 8]
      ]
      error_diffusion(img, palette, weights)
    end

    # Jarvis, Judice, and Ninke (JJN)
    def jjn(img, palette, gamma: 2.2)
      wts = []
      # Row 0
      wts << [1, 0, 7.0 / 48] << [2, 0, 5.0 / 48]
      # Row 1
      [[-2, 1, 3], [-1, 1, 5], [0, 1, 7], [1, 1, 5], [2, 1, 3]].each { |dx, dy, v| wts << [dx, dy, v / 48.0] }
      # Row 2
      [[-2, 2, 1], [-1, 2, 3], [0, 2, 5], [1, 2, 3], [2, 2, 1]].each { |dx, dy, v| wts << [dx, dy, v / 48.0] }
      error_diffusion(img, palette, wts)
    end

    # Stucki
    def stucki(img, palette, gamma: 2.2)
      wts = []
      # Row 0
      wts << [1, 0, 8.0 / 42] << [2, 0, 4.0 / 42]
      # Row 1
      [[-2, 1, 2], [-1, 1, 4], [0, 1, 8], [1, 1, 4], [2, 1, 2]].each { |dx, dy, v| wts << [dx, dy, v / 42.0] }
      # Row 2
      [[-2, 2, 1], [-1, 2, 2], [0, 2, 4], [1, 2, 2], [2, 2, 1]].each { |dx, dy, v| wts << [dx, dy, v / 42.0] }
      error_diffusion(img, palette, wts)
    end

    # Burkes
    def burkes(img, palette, gamma: 2.2)
      wts = []
      # Row 0
      wts << [1, 0, 8.0 / 32] << [2, 0, 4.0 / 32]
      # Row 1
      [[-2, 1, 2], [-1, 1, 4], [0, 1, 8], [1, 1, 4], [2, 1, 2]].each { |dx, dy, v| wts << [dx, dy, v / 32.0] }
      error_diffusion(img, palette, wts)
    end

    # Sierra (three-row)
    def sierra(img, palette, gamma: 2.2)
      wts = []
      # Row 0
      wts << [1, 0, 5.0 / 32] << [2, 0, 3.0 / 32]
      # Row 1
      [[-2, 1, 2], [-1, 1, 4], [0, 1, 5], [1, 1, 4], [2, 1, 2]].each { |dx, dy, v| wts << [dx, dy, v / 32.0] }
      # Row 2
      [[-1, 2, 2], [0, 2, 3], [1, 2, 2]].each { |dx, dy, v| wts << [dx, dy, v / 32.0] }
      error_diffusion(img, palette, wts)
    end

    # Sierra two-row
    def sierra2(img, palette, gamma: 2.2)
      wts = []
      wts << [1, 0, 4.0 / 16] << [2, 0, 3.0 / 16]
      [[-2, 1, 1], [-1, 1, 2], [0, 1, 3], [1, 1, 2], [2, 1, 1]].each { |dx, dy, v| wts << [dx, dy, v / 16.0] }
      error_diffusion(img, palette, wts)
    end

    # Sierra Lite
    def sierra_lite(img, palette, gamma: 2.2)
      wts = []
      wts << [1, 0, 2.0 / 4]
      [[-1, 1, 1], [0, 1, 1]].each { |dx, dy, v| wts << [dx, dy, v / 4.0] }
      error_diffusion(img, palette, wts)
    end

    # Stevenson–Arce
    def stevenson(img, palette, gamma: 2.2)
      scale = 1.0 / 200.0
      wts = []
      wts << [2, 0, 32 * scale]
      [[-3, 1, 12], [-1, 1, 26], [1, 1, 30], [3, 1, 16]].each { |dx, dy, v| wts << [dx, dy, v * scale] }
      [[-2, 2, 12], [0, 2, 26], [2, 2, 12]].each { |dx, dy, v| wts << [dx, dy, v * scale] }
      [[-3, 3, 5], [-1, 3, 12], [1, 3, 12], [3, 3, 5]].each { |dx, dy, v| wts << [dx, dy, v * scale] }
      error_diffusion(img, palette, wts)
    end

    # Ordered dithering helpers
    def ordered_with_matrix(img, palette, matrix, strength: 0.75)
      w = img.width
      h = img.height
      mh = matrix.length
      mw = matrix[0].length
      maxv = matrix.flatten.max.to_f
      out = Array.new(h) { Array.new(w) { [0, 0, 0] } }
      h.times do |y|
        w.times do |x|
          r, g, b = img.get_rgb(x, y)
          t = matrix[y % mh][x % mw]
          # Map matrix value around 0, scale to 0..255-ish, then apply strength
          bias = ((t - maxv / 2.0) / maxv) * 255.0 * strength
          cr = (r + bias).round.clamp(0, 255)
          cg = (g + bias).round.clamp(0, 255)
          cb = (b + bias).round.clamp(0, 255)
          nr, ng, nb = nearest_color(cr, cg, cb, palette)
          out[y][x] = [nr, ng, nb]
        end
      end
      out
    end

    # Ordered dithering using an 8x8 Bayer matrix. Applies a matrix-based bias before nearest-color mapping
    def ordered_bayer8(img, palette, gamma: 2.2, strength: 0.75)
      # 8x8 Bayer threshold map values 0..63
      bayer8 = [
        [0, 48, 12, 60, 3, 51, 15, 63],
        [32, 16, 44, 28, 35, 19, 47, 31],
        [8, 56, 4, 52, 11, 59, 7, 55],
        [40, 24, 36, 20, 43, 27, 39, 23],
        [2, 50, 14, 62, 1, 49, 13, 61],
        [34, 18, 46, 30, 33, 17, 45, 29],
        [10, 58, 6, 54, 9, 57, 5, 53],
        [42, 26, 38, 22, 41, 25, 37, 21]
      ]
      ordered_with_matrix(img, palette, bayer8, strength: 0.75)
    end

    def ordered_bayer4(img, palette, gamma: 2.2, strength: 0.75)
      m = [
        [0, 8, 2, 10],
        [12, 4, 14, 6],
        [3, 11, 1, 9],
        [15, 7, 13, 5]
      ]
      ordered_with_matrix(img, palette, m, strength: 0.75)
    end

    def ordered_bayer2(img, palette, gamma: 2.2, strength: 0.75)
      m = [
        [0, 2],
        [3, 1]
      ]
      ordered_with_matrix(img, palette, m, strength: 0.75)
    end

    # Clustered-dot 4x4 (classic halftone)
    def ordered_cluster4(img, palette, gamma: 2.2, strength: 0.85)
      m = [
        [14, 10, 11, 15],
        [9, 3, 0, 4],
        [8, 2, 1, 5],
        [13, 7, 6, 12]
      ]
      ordered_with_matrix(img, palette, m, strength: strength)
    end

    # Random dithering: add noise as a threshold bias
    def random(img, palette, gamma: 2.2, amount: 64)
      w = img.width
      h = img.height
      out = Array.new(h) { Array.new(w) { [0, 0, 0] } }
      h.times do |y|
        w.times do |x|
          r, g, b = img.get_rgb(x, y)
          bias = rand(-amount..amount)
          cr = (r + bias).clamp(0, 255)
          cg = (g + bias).clamp(0, 255)
          cb = (b + bias).clamp(0, 255)
          nr, ng, nb = nearest_color(cr, cg, cb, palette)
          out[y][x] = [nr, ng, nb]
        end
      end
      out
    end
  end

  class Canvas
    attr_reader :width, :height

    def initialize(chunky_image)
      @img = chunky_image
      @width = @img.width
      @height = @img.height
    end

    def get_rgb(x, y)
      pixel = @img[x, y]
      r = (pixel >> 24) & 0xFF
      g = (pixel >> 16) & 0xFF
      b = (pixel >> 8) & 0xFF
      [r, g, b]
    end
  end

  class OutputPNG
    def initialize(width, height)
      require 'chunky_png'
      @png = ChunkyPNG::Image.new(width, height, ChunkyPNG::Color::WHITE)
    end

    def set_rgb(x, y, r, g, b)
      @png[x, y] = ChunkyPNG::Color.rgba(r, g, b, 255)
    end

    def save(path)
      @png.save(path)
    end
  end

  def self.run(argv)
    if argv.include?('--help') || argv.length < 2
      puts HELP
      return 0
    end

    input = argv[0]
    output = argv[1]

    # Defaults
    palette_arg = 'bilevel'
    method = 'floyd'
    gamma = 2.2

    i = 2
    while i < argv.length
      case argv[i]
      when '--palette'
        palette_arg = argv[i + 1] or raise ArgumentError, 'Missing value for --palette'
        i += 2
      when '--method'
        method = argv[i + 1] or raise ArgumentError, 'Missing value for --method'
        i += 2
      when '--gamma'
        gamma = (argv[i + 1] || '2.2').to_f
        i += 2
      else
        Util.puts_err "Unknown option: #{argv[i]}"
        puts HELP
        return 1
      end
    end

    begin
      require 'chunky_png'
    rescue LoadError
      Util.puts_err "This tool requires the 'chunky_png' gem to read/write PNGs."
      Util.puts_err "Install it with: gem install chunky_png"
      return 2
    end

    unless File.exist?(input)
      Util.puts_err "Input not found: #{input}"
      return 3
    end

    begin
      png = ChunkyPNG::Image.from_file(input)
    rescue => e
      Util.puts_err "Failed to read PNG: #{e.message}"
      return 4
    end

    palette = Util.palette_from_arg(palette_arg)
    canvas = Canvas.new(png)

    mapped = case method
             when 'threshold'
               Dither.threshold_map(canvas, palette, gamma: gamma)
             when 'floyd'
               Dither.floyd_steinberg(canvas, palette, gamma: gamma)
             when 'atkinson'
               Dither.atkinson(canvas, palette, gamma: gamma)
             when 'jjn'
               Dither.jjn(canvas, palette, gamma: gamma)
             when 'stucki'
               Dither.stucki(canvas, palette, gamma: gamma)
             when 'burkes'
               Dither.burkes(canvas, palette, gamma: gamma)
             when 'sierra'
               Dither.sierra(canvas, palette, gamma: gamma)
             when 'sierra2'
               Dither.sierra2(canvas, palette, gamma: gamma)
             when 'sierra_lite'
               Dither.sierra_lite(canvas, palette, gamma: gamma)
             when 'stevenson'
               Dither.stevenson(canvas, palette, gamma: gamma)
             when 'bayer2'
               Dither.ordered_bayer2(canvas, palette, gamma: gamma)
             when 'bayer4'
               Dither.ordered_bayer4(canvas, palette, gamma: gamma)
             when 'bayer8'
               Dither.ordered_bayer8(canvas, palette, gamma: gamma)
             when 'cluster4'
               Dither.ordered_cluster4(canvas, palette, gamma: gamma)
             when 'random'
               Dither.random(canvas, palette, gamma: gamma)
             else
               Util.puts_err "Unknown method: #{method}"
               return 1
             end

    out = OutputPNG.new(canvas.width, canvas.height)
    canvas.height.times do |y|
      canvas.width.times do |x|
        r, g, b = mapped[y][x]
        out.set_rgb(x, y, r, g, b)
      end
    end

    begin
      out.save(output)
    rescue => e
      Util.puts_err "Failed to save output: #{e.message}"
      return 5
    end

    0
  end
end
