# frozen_string_literal: true

# graingem - a tiny image dithering CLI
# Entry point

require_relative 'ui'

if __FILE__ == $PROGRAM_NAME
  exit UI.run(ARGV)
end
